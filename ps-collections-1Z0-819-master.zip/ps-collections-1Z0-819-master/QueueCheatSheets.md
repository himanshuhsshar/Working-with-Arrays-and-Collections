## Queue methods to Know

| Method        | Return Type          | Parameters                            |
|---------------|----------------------|---------------------------------------|
|add()          | boolean              | (E element)                           |
|remove()       | boolean              | (Object object)                       |
|isEmpty()      | boolean              | none                                  |
|size()         | int                  | none                                  |
|element()      | E                    | none                                  |
|offer()        | boolean              | (E element)                           |
|poll()         | E                    | none                                  |
|peek()         | E                    | none                                  |
